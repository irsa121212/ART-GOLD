const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const defaultProducts = [
  {id:1,name:"Golden Eclipse Ring",category:"Unaza",price:420,stock:5,image:"https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=900&q=80"},
  {id:2,name:"Aurora Necklace",category:"Varëse",price:680,stock:3,image:"https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=900&q=80"},
  {id:3,name:"Celeste Bracelet",category:"Byzylykë",price:350,stock:8,image:"https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&w=900&q=80"},
  {id:4,name:"Luna Earrings",category:"Vathë",price:290,stock:0,image:"https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80"},
  {id:5,name:"Royal Gold Watch",category:"Ora",price:980,stock:4,image:"https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=900&q=80"},
  {id:6,name:"Velvet Heart Ring",category:"Unaza",price:510,stock:9,image:"https://images.unsplash.com/photo-1627293509201-cd0c780043e6?auto=format&fit=crop&w=900&q=80"}
];
const defaultEmployees = [
  {id:1,name:"Amelia K.",role:"Menaxhere Dyqani",schedule:"Me kohë të plotë",salary:1200,email:"amelia@artgold.al",phone:"+355 69 111 2233",status:"Aktiv"},
  {id:2,name:"Daniel R.",role:"Këshilltar Shitjesh",schedule:"Me kohë të plotë",salary:850,email:"daniel@artgold.al",phone:"+355 69 222 3344",status:"Aktiv"},
  {id:3,name:"Sara M.",role:"Konsulente Bizhuterish",schedule:"Me kohë të pjesshme",salary:600,email:"sara@artgold.al",phone:"+355 69 333 4455",status:"Aktiv"},
  {id:4,name:"Leo B.",role:"Menaxher Inventari",schedule:"Me kohë të plotë",salary:900,email:"leo@artgold.al",phone:"+355 69 444 5566",status:"Aktiv"}
];
const defaultSales = [
  {id:"AG1028",productId:1,productName:"Golden Eclipse Ring",customer:"Emma D.",date:"2026-09-24",qty:1,total:420},
  {id:"AG1027",productId:2,productName:"Aurora Necklace",customer:"Mia R.",date:"2026-09-23",qty:1,total:680},
  {id:"AG1026",productId:3,productName:"Celeste Bracelet",customer:"Lea K.",date:"2026-09-22",qty:2,total:700}
];

let products = JSON.parse(localStorage.getItem("ag_products")) || defaultProducts;
let employees = JSON.parse(localStorage.getItem("ag_employees")) || defaultEmployees;
let sales = JSON.parse(localStorage.getItem("ag_sales")) || defaultSales;
let activities = JSON.parse(localStorage.getItem("ag_activities")) || [
  {text:"Shitja AG1028 u përfundua",time:"Sot"},
  {text:"Stoku i Aurora Necklace u përditësua",time:"Dje"},
  {text:"Sara M. u shtua në ekip",time:"2 ditë më parë"}
];

function saveAll(){
  localStorage.setItem("ag_products",JSON.stringify(products));
  localStorage.setItem("ag_employees",JSON.stringify(employees));
  localStorage.setItem("ag_sales",JSON.stringify(sales));
  localStorage.setItem("ag_activities",JSON.stringify(activities.slice(0,8)));
}

function euro(n){return new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR",maximumFractionDigits:0}).format(n||0)}
function uid(){return Date.now()+Math.floor(Math.random()*1000)}
function productStatus(stock){
  if(stock===0) return {label:"Mbaruar",cls:"out",key:"soldout"};
  if(stock<=5) return {label:"Stok i ulët",cls:"low",key:"low"};
  return {label:"Në gjendje",cls:"ok",key:"available"};
}
function toast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.remove("hidden");
  setTimeout(()=>t.classList.add("hidden"),2200);
}
function addActivity(text){
  activities.unshift({text,time:new Date().toLocaleDateString("sq-AL")});
  saveAll();
}

$("#loginForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  if($("#loginUser").value.trim()==="admin" && $("#loginPass").value==="1234"){
    $("#loginView").classList.add("hidden");
    $("#app").classList.remove("hidden");
    renderAll();
  }else{
    $("#loginError").textContent="Përdoruesi ose fjalëkalimi nuk është i saktë.";
  }
});
$("#logoutBtn").addEventListener("click",()=>{
  $("#app").classList.add("hidden");
  $("#loginView").classList.remove("hidden");
  $("#loginPass").value="";
});

function showSection(id){
  $$(".page-section").forEach(s=>s.classList.toggle("active",s.id===id));
  $$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.section===id));
  const titles={dashboard:"Mirë se u riktheve, ART GOLD",products:"Inventari i ART GOLD",employees:"Ekipi i ART GOLD",sales:"Shitjet e ART GOLD",analytics:"Analitika e biznesit"};
  $("#sectionTitle").textContent=titles[id]||"ART GOLD";
}
$$(".nav-link").forEach(b=>b.addEventListener("click",()=>showSection(b.dataset.section)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>showSection(b.dataset.go)));

function renderDashboard(){
  const revenue=sales.reduce((s,x)=>s+x.total,0);
  $("#statProducts").textContent=products.length;
  $("#statEmployees").textContent=employees.length;
  $("#statSales").textContent=sales.length;
  $("#statRevenue").textContent=euro(revenue);

  const months=[{m:"JAN",v:8200},{m:"SHK",v:10500},{m:"MAR",v:9700},{m:"PRI",v:13400},{m:"MAJ",v:15200},{m:"QER",v:Math.max(18450,revenue)}];
  const max=Math.max(...months.map(x=>x.v));
  $("#salesChart").innerHTML=months.map(x=>`<div class="bar-item"><div class="bar" style="height:${Math.max(12,x.v/max*190)}px" data-value="${euro(x.v)}"></div><span>${x.m}</span></div>`).join("");

  $("#activityList").innerHTML=activities.slice(0,5).map(a=>`<div class="activity-item">${a.text}<small>${a.time}</small></div>`).join("")||`<div class="empty">Nuk ka aktivitete.</div>`;

  const alerts=products.filter(p=>p.stock<=5);
  $("#stockAlerts").innerHTML=alerts.map(p=>`<div class="alert-item"><strong>${p.name}</strong><small>${p.stock===0?"Produkti ka mbaruar.":`Kanë mbetur vetëm ${p.stock} copë.`}</small></div>`).join("")||`<div class="empty">Stoku është në gjendje të mirë.</div>`;

  const soldCount={};
  sales.forEach(s=>soldCount[s.productName]=(soldCount[s.productName]||0)+s.qty);
  const best=Object.entries(soldCount).sort((a,b)=>b[1]-a[1])[0];
  $("#bestProduct").textContent=best?best[0]:"—";
  $("#bestProductMeta").textContent=best?`${best[1]} copë të shitura`:"Nuk ka ende të dhëna";
}

function renderProducts(){
  const q=$("#productSearch").value.toLowerCase();
  const cat=$("#categoryFilter").value;
  const st=$("#stockFilter").value;
  const list=products.filter(p=>{
    const status=productStatus(p.stock).key;
    return p.name.toLowerCase().includes(q) && (cat==="all"||p.category===cat) && (st==="all"||status===st);
  });
  $("#productGrid").innerHTML=list.map(p=>{
    const s=productStatus(p.stock);
    return `<article class="product-card">
      <div class="product-image"><img src="${p.image||"https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=900&q=80"}" alt="${p.name}"></div>
      <div class="product-info">
        <div class="product-top"><div><h4>${p.name}</h4><p>${p.category}</p></div><div class="price">${euro(p.price)}</div></div>
        <div class="meta-row"><span>Stok: <strong>${p.stock}</strong></span><span class="badge ${s.cls}">${s.label}</span></div>
        <div class="card-actions">
          <button onclick="editProduct(${p.id})">Ndrysho</button>
          <button class="danger" onclick="deleteProduct(${p.id})">Fshi</button>
        </div>
      </div>
    </article>`;
  }).join("") || `<div class="empty">Nuk u gjet asnjë produkt.</div>`;
  fillSaleProducts();
}
["input","change"].forEach(evt=>$("#productSearch").addEventListener(evt,renderProducts));
$("#categoryFilter").addEventListener("change",renderProducts);
$("#stockFilter").addEventListener("change",renderProducts);

function renderEmployees(){
  $("#employeeTableBody").innerHTML=employees.map(e=>`<tr>
    <td><div class="table-person"><strong>${e.name}</strong><span>${e.email}</span></div></td>
    <td>${e.role}</td><td>${e.schedule}</td><td>${euro(e.salary)}</td>
    <td><span class="badge ok">${e.status}</span></td>
    <td><button class="small-btn" onclick="editEmployee(${e.id})">Ndrysho</button><button class="small-btn danger" onclick="deleteEmployee(${e.id})">Fshi</button></td>
  </tr>`).join("");
}

function renderSales(){
  const revenue=sales.reduce((s,x)=>s+x.total,0);
  $("#salesCountBig").textContent=sales.length;
  $("#salesRevenueBig").textContent=euro(revenue);
  $("#salesAverageBig").textContent=euro(sales.length?revenue/sales.length:0);
  $("#salesTableBody").innerHTML=[...sales].reverse().map(s=>`<tr>
    <td>#${s.id}</td><td>${s.productName}</td><td>${s.customer}</td>
    <td>${new Date(s.date).toLocaleDateString("sq-AL")}</td><td>${s.qty}</td><td>${euro(s.total)}</td>
  </tr>`).join("") || `<tr><td colspan="6">Nuk ka shitje.</td></tr>`;
}

function renderAnalytics(){
  const catCount={}; products.forEach(p=>catCount[p.category]=(catCount[p.category]||0)+1);
  const top=Object.entries(catCount).sort((a,b)=>b[1]-a[1])[0];
  $("#topCategory").textContent=top?top[0]:"—";
  $("#inventoryValue").textContent=euro(products.reduce((s,p)=>s+p.price*p.stock,0));
  $("#lowStockCount").textContent=products.filter(p=>p.stock<=5).length;
  $("#salaryTotal").textContent=euro(employees.reduce((s,e)=>s+e.salary,0));
  const count={}; sales.forEach(s=>count[s.productName]=(count[s.productName]||0)+s.qty);
  const ranking=Object.entries(count).sort((a,b)=>b[1]-a[1]);
  $("#productSalesRanking").innerHTML=ranking.map((r,i)=>`<div class="rank-item"><div class="rank-number">${i+1}</div><div><strong>${r[0]}</strong><span>${r[1]} copë të shitura</span></div><strong>${r[1]}</strong></div>`).join("")||`<div class="empty">Nuk ka ende të dhëna për shitjet.</div>`;
}
function renderAll(){renderDashboard();renderProducts();renderEmployees();renderSales();renderAnalytics();}

function openModal(id){$("#modalBackdrop").classList.remove("hidden");$(id).classList.remove("hidden")}
function closeModals(){ $("#modalBackdrop").classList.add("hidden"); $$(".modal").forEach(m=>m.classList.add("hidden")); }
$$("[data-close]").forEach(b=>b.addEventListener("click",closeModals));
$("#modalBackdrop").addEventListener("click",closeModals);

$("#openProductModal").addEventListener("click",()=>{
  $("#productForm").reset();$("#productId").value="";$("#productModalTitle").textContent="Shto produkt";openModal("#productModal");
});
window.editProduct=(id)=>{
  const p=products.find(x=>x.id===id); if(!p)return;
  $("#productId").value=p.id;$("#productName").value=p.name;$("#productCategory").value=p.category;$("#productPrice").value=p.price;$("#productStock").value=p.stock;$("#productImage").value=p.image;
  $("#productModalTitle").textContent="Ndrysho produktin";openModal("#productModal");
};
window.deleteProduct=(id)=>{
  const p=products.find(x=>x.id===id);
  if(p && confirm(`Ta fshijmë "${p.name}" nga inventari?`)){
    products=products.filter(x=>x.id!==id);addActivity(`Produkti ${p.name} u fshi nga inventari`);saveAll();renderAll();toast("Produkti u fshi.");
  }
};
$("#productForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const id=Number($("#productId").value);
  const item={id:id||uid(),name:$("#productName").value.trim(),category:$("#productCategory").value,price:Number($("#productPrice").value),stock:Number($("#productStock").value),image:$("#productImage").value.trim()};
  if(id){products=products.map(p=>p.id===id?item:p);addActivity(`Produkti ${item.name} u përditësua`);}
  else{products.push(item);addActivity(`U shtua produkti i ri: ${item.name}`);}
  saveAll();closeModals();renderAll();toast(id?"Produkti u përditësua.":"Produkti u shtua.");
});

$("#openEmployeeModal").addEventListener("click",()=>{
  $("#employeeForm").reset();$("#employeeId").value="";$("#employeeModalTitle").textContent="Shto punonjës";openModal("#employeeModal");
});
window.editEmployee=(id)=>{
  const e=employees.find(x=>x.id===id);if(!e)return;
  $("#employeeId").value=e.id;$("#employeeName").value=e.name;$("#employeeRole").value=e.role;$("#employeeSchedule").value=e.schedule;$("#employeeSalary").value=e.salary;$("#employeeEmail").value=e.email;$("#employeePhone").value=e.phone;
  $("#employeeModalTitle").textContent="Ndrysho punonjësin";openModal("#employeeModal");
};
window.deleteEmployee=(id)=>{
  const e=employees.find(x=>x.id===id);
  if(e&&confirm(`Ta heqim ${e.name} nga ekipi?`)){employees=employees.filter(x=>x.id!==id);addActivity(`${e.name} u hoq nga ekipi`);saveAll();renderAll();toast("Punonjësi u hoq.");}
};
$("#employeeForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const id=Number($("#employeeId").value);
  const item={id:id||uid(),name:$("#employeeName").value.trim(),role:$("#employeeRole").value.trim(),schedule:$("#employeeSchedule").value,salary:Number($("#employeeSalary").value),email:$("#employeeEmail").value.trim(),phone:$("#employeePhone").value.trim(),status:"Aktiv"};
  if(id){employees=employees.map(x=>x.id===id?item:x);addActivity(`Të dhënat e ${item.name} u përditësuan`);}
  else{employees.push(item);addActivity(`U shtua punonjësi ${item.name}`);}
  saveAll();closeModals();renderAll();toast(id?"Punonjësi u përditësua.":"Punonjësi u shtua.");
});

function fillSaleProducts(){
  const available=products.filter(p=>p.stock>0);
  $("#saleProduct").innerHTML=available.map(p=>`<option value="${p.id}">${p.name} — ${euro(p.price)} — stok ${p.stock}</option>`).join("");
}
$("#openSaleModal").addEventListener("click",()=>{
  fillSaleProducts();$("#saleForm").reset();$("#saleDate").value=new Date().toISOString().slice(0,10);openModal("#saleModal");
});
$("#saleForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const pid=Number($("#saleProduct").value),qty=Number($("#saleQty").value),p=products.find(x=>x.id===pid);
  if(!p)return;
  if(qty>p.stock){toast("Sasia është më e madhe se stoku.");return;}
  p.stock-=qty;
  const id="AG"+String(1000+sales.length+29);
  sales.push({id,productId:p.id,productName:p.name,customer:$("#saleCustomer").value.trim(),date:$("#saleDate").value,qty,total:p.price*qty});
  addActivity(`Shitja ${id} u regjistrua për ${p.name}`);
  saveAll();closeModals();renderAll();toast("Shitja u regjistrua me sukses.");
});

$("#liveDate").textContent=new Date().toLocaleDateString("sq-AL",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
