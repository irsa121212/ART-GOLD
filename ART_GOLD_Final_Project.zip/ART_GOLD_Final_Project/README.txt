ART GOLD – Projekt Final HTML/CSS/JavaScript

Hap index.html në browser.

Login demo:
Përdoruesi: admin
Fjalëkalimi: 1234

Funksione:
- Dashboard me statistika
- Menaxhim produktesh: shto, ndrysho, fshi
- Kërkim dhe filtrim
- Menaxhim punonjësish
- Regjistrim shitjesh
- Përditësim automatik i stokut
- Analitika
- LocalStorage
- Responsive design

Skedarët:
index.html
style.css
script.js
